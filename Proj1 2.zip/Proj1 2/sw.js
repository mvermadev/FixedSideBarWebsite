// var cacheName = 'codemy_v1';
// var cacheFiles = [
//   '/',
//   '/index.html',
//   '/style.css',
//   '/script.js',
//   '/img/bg.jpg',
//   '/google.jpg',
//   '/hmg.jpg',
//   '/icn.jpg',
//   '/poster.jpg',
//   '/vid/movie.mp4'
// ];

//Install serviceWorker:
self.addEventListener('install' , function(e){
  console.log('serviceWorker is installed');
  e.waitUntil(
    caches.open('static').then(function(cache){
      console.log('serviceWorker is caching App Shell');
      return cache.addAll([
        '/',
        '/index.html',
        '/style.css',
        '/script.js',
        '/img/bg.jpg',
        '/google.jpg',
        '/hmg.jpg',
        '/icn.jpg',
        '/poster.jpg',
        '/vid/movie.mp4'
      ]);
    })
    );
  });

//half activation of serviceWorker code:
self.addEventListener('activate', function(e) {
  console.log('serviceworker is activated');
}); 

//activate serviceWorker:
// self.addEventListener('activate', (e)=>{
//   console.log('serviceWorker is activate');
//   e.waitUntil(
//     caches.keys().then((keyList)=>{
//       return Promise.all(keyList.map((key)=>{
//         if (key !== cacheName) {
//           console.log('serviceWorker is removing old cache', key);
//           return caches.delete(key);
//         }
//       }));
//     })
//   );
  // return self.clients().claim(); // its update data every time whenever we reload.
// });

//serve the appShell from the cache(or fetch files from network or server):
// self.addEventListener('fetch', (e)=>{
//   console.log('serviceWorker is fetching : ', e.request.url);
//   e.respondWith(
//     caches.match(e.request).then((res)=>{
//       return res || fetch(e.request);
//     })
//   );
// });

//conditional fetch:
self.addEventListener('fetch', function(e){
  console.log('fetching request : ', e.request.url);
e.respondWith(
    caches.match(e.request).then(function(res) {
      if (res) {
          return res;
      }
      else{
        return fetch(e.request);
      }
    })
);
});
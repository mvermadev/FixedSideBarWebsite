// var myCacheName = 'pwaCache';
// var myCacheFiles = [
//   './',
//   './index.html',
//   './style.css',
//   './script.js',
//   './img/bg.jpg',
//   './google.jpg',
//   './hmg.jpg',
//   './icn.jpg',
//   './poster.jpg',
//   './vid/movie.mp4'
// ];

//install serviceWorker:
self.addEventListener('install', function(event){
  console.log('serviceWorker is installed');
  event.waitUntil(caches.open("staticPwaCache").then(function(cache){
    console.log('serviceWorker is caching App Shell');
        cache.addAll( [
        './',
        './index.html',
        './script.js',
        './style.css',
        './img/bg.jpg',
        './google.jpg',
        './hmg.jpg',
        './icn.jpg',
        './poster.jpg',
        './vid/movie.mp4'
      ]);
    })
  );
});

//activate serviceWorker:
self.addEventListener('activate', function(event){
  console.log('serviceWorker activate');
})



//fetch serviceWorker:
self.addEventListener('fetch', function(event){
  console.log('serviceWorker fetching : ', event.request.url);
  event.respondWith(
    caches.match(event.request).then(function(response){
      return response || fetch(event.request);
    })
  );
});

//Add serviceWorker:
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js')
    .then(function(){
      console.log('serviceWorker is Registered');
    })
    .catch(()=>console.log('serviceWorker is NOT Registered'))
  }


function openNav(){
  // document.getElementById('sde').style.display= 'block';
    document.getElementById("mysde").style.display = "block";
    document.getElementById("mainly").style.opacity = "0.5";
    document.body.style.overflowY = "hidden";
    // document.body.style.backgroundColor = "rgb(0,0,0,0.4)";
    // document.getElementById("mainly").style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav(){
    var x = window.matchMedia("(max-width: 800px)");
    if (x.matches) {
        document.getElementById("mysde").style.display = "none";
        document.getElementById("mainly").style.opacity = "1";
        document.body.style.overflowY = "scroll";
        // document.getElementById("mainly").style.backgroundColor = "white";
        return true
        }
        return false;

}

// fetch Videos:
var myHeaders = new Headers();

var myInit = {  method: 'get',
                headers: myHeaders,
                mode : 'cors',
                cache : 'default'
}

var myRequest = new Request('./vid/movie.mp4',myInit  );

var video = document.getElementById('vids');
// fetch('./vid/movie.mp4').then((res)=>res.blob())
// .then((res)=>{
//         var objurl = URL.createObjectURL(res);
//         video.src = objurl;
//     }
// )

//Fetch with conditional method:
fetch(myRequest)
.then((res)=>{
    if (res.ok) {
        return res.blob();
    }
    throw new Error('Sorry, video is not fetch:(');
})
.then((res)=>{
    var objurl = URL.createObjectURL(res);
    video.src = objurl;
})
.catch((err)=>console.log('There was a some problem with fetch operation : ', err))

//fetch poster:
myRequest = new Request('./img/poster.jpeg', myInit);
fetch(myRequest)
.then((res)=>{
    if (res.ok) {
        return res.blob();
    }
    throw new Error('Error in response');
})
.then((res)=>{
    var objurl = URL.createObjectURL(res);
    video.poster = objurl;
})


// fetch bg:
// document.getElementById('img')
self.addEventListener('load', fetching);

function fetching(){
    var back = document.getElementById('bg');
 return fetch('./img/bg.jpeg')
        .then((res) => res.blob())
        .then((res) => {
            var objurl = URL.createObjectURL(res);
            back.style.backgroundImage = "url(" + objurl + ")";
        })
        .catch((err) => console.log('There was some error ', err))
}

//Modal trap:
var focusedElementBeforeModal;

var modal = document.getElementById('acs');
var modalToggle = document.getElementById('openbar');
modalToggle.addEventListener('click', openModal);

function openModal(){

  focusedElementBeforeModal = document.activeElement;

  modal.addEventListener('keydown', trapTabkey);

  var focusableElementsString = 'a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex="0"], [contenteditable]';

  var focusableElements = modal.querySelectorAll(focusableElementsString);

  focusableElements = Array.prototype.slice.call(focusableElements);

  var firstTabStop = focusableElements[0];
  var lastTabStop = focusableElements[focusableElements.length-1];

  modal.style.display = 'block';

  firstTabStop.focus();

  function trapTabkey(e){
    //check for TAB key press
    if (e.keyCode === 9) {

        //shift + tab;
        if (e.shiftKey) {
          if (document.activeElement === firstTabStop) {
              e.preventDefault();
              lastTabStop.focus();
          }
        }
        else{
          if (document.activeElement === lastTabStop) {
            e.preventDefault();
            firstTabStop.focus();
          }
        }
    }

    //Escape
    if (e.keyCode === 27) {
        closeModal();
    }

  }

}

function closeModal(){
  modal.style.display = 'none';
  document.getElementById("mainly").style.opacity = "1";

  focusedElementBeforeModal.focus();
}

function getData(key, label){
  var app = document.querySelector('body');

  if ('caches' in window) {

    caches.match(url).then((res)=>{
      if (res) {
        res.json().then(function updateFromCache(json){
          var results = json.query.results;
          results.key =  key;
          results.label = label;
          results.created = json.query.created;
          app.updateFromCache(results);
        })
      }
    })
  }
}
